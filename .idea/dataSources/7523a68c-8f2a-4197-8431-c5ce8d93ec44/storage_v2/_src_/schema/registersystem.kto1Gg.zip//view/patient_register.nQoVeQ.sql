create definer = root@localhost view patient_register as
select `registersystem`.`register`.`register_id`     AS `register_id`,
       `registersystem`.`patient`.`patient_id`       AS `patient_id`,
       `registersystem`.`doctor`.`doctor_id`         AS `doctor_id`,
       `registersystem`.`patient`.`patient_name`     AS `patient_name`,
       `registersystem`.`patient`.`patient_gender`   AS `patient_gender`,
       `registersystem`.`patient`.`patient_age`      AS `patient_age`,
       `registersystem`.`patient`.`patient_tel`      AS `patient_tel`,
       `registersystem`.`patient`.`patient_address`  AS `patient_address`,
       `registersystem`.`register`.`register_time`   AS `register_time`,
       `registersystem`.`dept`.`dept_name`           AS `dept_name`,
       `registersystem`.`register`.`register_status` AS `register_status`,
       `registersystem`.`post`.`post_name`           AS `post_name`,
       `registersystem`.`doctor`.`doctor_name`       AS `doctor_name`
from ((((`registersystem`.`register` left join `registersystem`.`patient` on ((
        `registersystem`.`register`.`patient_id` =
        `registersystem`.`patient`.`patient_id`))) left join `registersystem`.`doctor` on ((
        `registersystem`.`doctor`.`doctor_id` =
        `registersystem`.`register`.`doctor_id`))) left join `registersystem`.`dept` on ((
        `registersystem`.`dept`.`dept_id` = `registersystem`.`doctor`.`dept_id`)))
         left join `registersystem`.`post`
                   on ((`registersystem`.`doctor`.`post_id` = `registersystem`.`post`.`post_id`)));

-- comment on column patient_register.register_status not supported: 默认2，0代表已处理，2代表未处理，1代表正在处理


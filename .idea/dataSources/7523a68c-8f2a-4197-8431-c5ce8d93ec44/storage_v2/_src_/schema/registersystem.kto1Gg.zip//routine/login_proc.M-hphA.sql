create
    definer = root@localhost procedure login_proc(IN uname varchar(20), IN upassword varchar(20), IN type int)
BEGIN
	SELECT 
	*
	from account
	WHERE 
		account_name = uname
	and
		account_password = upassword
	and
		account_type=type;
END;


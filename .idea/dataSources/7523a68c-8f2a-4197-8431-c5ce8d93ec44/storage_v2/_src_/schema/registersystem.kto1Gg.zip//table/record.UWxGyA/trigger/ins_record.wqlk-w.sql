create definer = root@localhost trigger ins_record
    after insert
    on record
    for each row
begin 
 UPDATE register set register_status = 0
 WHERE register_id = new.register_id;
end;

